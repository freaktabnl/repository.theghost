service.ghostautosubs
===============

Zoekt automatisch de de gewenste ondertitels welke u vervolgens kunt selecteren. Met dank aan de originele ontwikkelaars<br>

Bevat onderstaande opties:
- Bepaalde paden uitsluiten
- Bepaalde woorden uitsluiten
- Zoek op specifieke taal alleen
- Live TV uitschakelen voor ondertitels
