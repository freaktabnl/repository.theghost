# plugin.video.ghostplaylistloader
M3U player voor Kodi Matrix
