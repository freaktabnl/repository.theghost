# plugin.video.hanssettings

KODI - Addon for Kanalenlijst Hans (but then only the streams)

Kanalenlijst Hans - Watch free stream from collected lib https://www.detransponder.nl/downloads-2/kanalenlijsten/
My git version https://github.com/Opvolger/plugin.video.hanssettings

## Buy me a beer / betaal een biertje voor mij

[![Donate-Ideal](https://img.shields.io/badge/Donate-Ideal-green.svg)](https://www.bunq.me/opvolger)
