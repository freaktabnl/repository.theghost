# plugin.video.uitzendinggemistnet
 Werkt alleen voor RTL 4/5/7/8. Gebruik Retrospect addon voor andere kanalen.
